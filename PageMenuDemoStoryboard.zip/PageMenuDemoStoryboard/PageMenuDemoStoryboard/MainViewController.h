//
//  MainViewController.h
//  PageMenuDemoStoryboard
//
//  Created by Venkat on 1/4/16.
//  Copyright (c) 2016 Jin Sasaki. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface MainViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIButton *send;
- (IBAction)sendData:(id)sender;

@end
