//
//  MainViewController.m
//  PageMenuDemoStoryboard
//
//  Created by Venkat on 1/4/16.
//  Copyright (c) 2016 Jin Sasaki. All rights reserved.
//

#import "MainViewController.h"

@interface MainViewController ()

@property (nonatomic) NSArray *namesArray;
@property (nonatomic) NSArray *photoNameArray;

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.namesArray = @[@"Lauren Richard", @"Nicholas Ray", @"Kim White", @"Charles Gray", @"Timothy Jones", @"Sarah Underwood", @"William Pearl", @"Juan Rodriguez", @"Anna Hunt", @"Marie Turner", @"George Porter", @"Zachary Hecker", @"David Fletcher"];
    
    self.photoNameArray= @[@"woman5.jpg", @"man1.jpg", @"woman1.jpg", @"man2.jpg", @"man3.jpg", @"woman2.jpg", @"man4.jpg", @"man5.jpg", @"woman3.jpg", @"woman4.jpg", @"man6.jpg", @"man7.jpg", @"man8.jpg"];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)sendData:(id)sender {
    
    ViewController *details = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    [self.navigationController pushViewController:details animated:YES];
}

@end
